main();
function main()
{      
        sourceDoc = app.activeDocument;
        sourceDoc.close(SaveOptions.SAVECHANGES); 
 }